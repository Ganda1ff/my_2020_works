<?php
    $DB_HOST = "127.0.0.1:3306";
    $DB_USER = "root";
    $DB_PASSWORD = "";
    $DB = "haker";
?>