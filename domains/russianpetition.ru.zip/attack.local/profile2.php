<title>Ваш профиль</title>
<style>
    img {
        margin-left:470px;
    }
    p {
        font-size:24px;
        font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
        margin-left:460px;
    }
    h1 {
        font-size: 30px;
        width:900px;
        margin-left:200px;
        font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    }
    #submit {
    background-color: #adc2df;
    font-family: 'Google Sans',arial,sans-serif;
    color:#fff;
    font-weight: bold;
    width:360px;
    height:50px;
    line-height: 20px;
    padding:8px;
    font-size: 16px;
    letter-spacing: .25px;
    cursor:pointer;
    border:none;
    margin-top:0px;
    float:center;
    margin-left:430px;
    border-radius: 50px;
    
}
#submit:hover,
#submit:active {
    background-color: #9bb8e0;
}
#submit2 {
    background-color: #fff;
    font-family: 'Google Sans',arial,sans-serif;
    color:#adc2df;
    font-weight: bold;
    width:360px;
    height:50px;
    line-height: 20px;
    padding:8px;
    font-size: 16px;
    letter-spacing: .25px;
    cursor:pointer;
    border:2px solid #adc2df;
    margin-top:0px;
    float:center;
    margin-left:430px;
    border-radius: 50px;
    margin-top:10px;
    outline:none;
}
#submit2:hover,
#submit2:active {
    background-color: #ebf4ff;
}
</style>
<img src="https://static.change.org/profile-img/default-user-profile.svg" width=300 height=300>
<p>Имя: Пользователь_27</p>
<p>Дата регистрации: Сегодня</p>
<h1>В вашем профиле пока недостаточно данных. Это никак не влияет на возможность голосовать. Позже вы сможете дополнить информацию о себе.</h1>
<a href="main2.php"><input type="submit" id="submit" value="Вернуться к петиции"></a>
<a href="main3.php"><input type="submit" id="submit2" value="Выйти"></a>