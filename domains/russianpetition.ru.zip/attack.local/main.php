<title>Животные не для развлечения</title>
<style>
        .name {
    font-family: 'Molengo', Georgia, Times, serif;
    font-size:44px;
    margin-top:-75px;
    margin-left:80px;
    user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
}
.slogan {
margin-top:-5px;
margin-left:105px;
margin-bottom:300px;
font-size: 18px;
font-family:'Monserrat', sans-serif;
-moz-user-select: none;
-khtml-user-select: none;
user-select: none;    
-moz-user-select: none;
    -webkit-user-select: none;
}
.h4 {
    color:#202124;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
width:30%;
margin-left:410px;
margin-bottom:20px;
pointer-events:none;
-webkit-user-select: none;
user-select: none;
-moz-user-select: none;
}
#blockq {
cursor:pointer;
}
.img1 {
    border-radius: 50%;
    width:300px;
    height:auto;
    margin-left:300px;
    margin-bottom:10px;
}
.img1:hover {
    cursor:pointer;
}
.h1 {
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-size:40px;
    font-weight: bold;  
    width:870px;
    margin-top:-280px;
    margin-left: 280px;
}
img {
    border-radius:10px;
}
.img2 {
margin-left: 295px;
margin-top:10px;
pointer-events: none;
user-select: none;
-moz-user-select: none;
-webkit-user-select: none;
}
.img3 {
    cursor: pointer;
    margin-left:620px;
    margin-top:-80px;
}
.username {
    color:darkslategrey;
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-weight: bold;
    margin-left:700px;
    margin-top:-60px;
    cursor:pointer;
    width:200px;
}

#b {
    width:200px;
}
.main {
    font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-weight: 100;
    margin-top:20px;
    width:600px;
    margin-left:300px;
    font-size: 20px;
}
.sub {
    background-color: #adc2df;
    font-family: 'Google Sans',arial,sans-serif;
    color:#fff;
    font-weight: bold;
    width:350px;
    height:50px;
    line-height: 20px;
    padding:8px;
    font-size: 16px;
    letter-spacing: .25px;
    cursor:pointer;
    border:none;
    margin-top:0px;
    float:center;
    margin-left:400px;
    border-radius: 50px;
    margin-top:20px;
    outline:none;
}
.sub:hover,
.sub:active {
    background-color: #9bb8e0;
    outline:none;
}
.i {
   float:right;
  
}

</style>
<link href="https://fonts.googleapis.com/css?family=Molengo" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lekton" rel="stylesheet">
    <div id="blockq">

    <div class="i">
        
    
        <a href="profile.php"><img src="https://static.change.org/profile-img/default-user-profile.svg" width=70 height=70></a>
    
    </div>
<div class="img"><img src="https://lh3.googleusercontent.com/8k-E0CX6s7fYwEhBPG6d_R1oxfLOHvYJtm4Fs2f7-kypdnbMGpjZVYHl9oKNPuIBjuk" width=70 peight=70><div class="name">RussianPetition</div></div>
   <div class="slogan">Изменим Россию к лучшему!</div>
   
    </div>
    <div class="h1">Животные не для развлечения</div>
    <div class="img1"><img src="https://assets.change.org/photos/6/sb/oh/GsSbohSGPZkqEAW-800x450-noPad.jpg?1512844321" width=580></div>
    <div class="img2"><img src="/p.png"></div>
    <div id="b">
    <div class="img3"><img src="https://static.change.org/profile-img/default-user-profile.svg" width=70 height=70></div>
    <div class="username">Пользователь_1
        Создал(а) эту петицию 23.04.2020
    </div>
</div>
<div class="main">
На центральной улице нашего города ради развлечения детей стоят кони, верблюд и олень. На них редко катаются. Находясь там весь день, животные пребывают в плачевном состоянии как физическом, так и в моральном. Их разодели в цветную "мишуру" и довольно часто кричат на них. Очень хотелось бы прекратить всё это. Сейчас 21 век, дети развлекаются иначе. Они спокойно могут обойтись без "покатушек на пони" и понять чувства животных с малых лет. 
</div>
<a href="main2.php"><input type="submit" value="Поддержать петицию" class="sub"></a>