<style>
.name {
    font-family: 'Molengo', Georgia, Times, serif;
    font-size:44px;
    margin-top:-75px;
    margin-left:80px;
    user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
}
.slogan {
margin-top:-5px;
margin-left:105px;
margin-bottom:300px;
font-size: 18px;
font-family:'Monserrat', sans-serif;
-moz-user-select: none;
-khtml-user-select: none;
user-select: none;    
-moz-user-select: none;
    -webkit-user-select: none;

}
#sub {
    background-color: #5181b8;
    font-family: 'Google Sans',arial,sans-serif;
    color:#fff;
    font-weight: bold;
    width:360px;
    height:50px;
    line-height: 20px;
    padding:8px;
    font-size: 16px;
    letter-spacing: .25px;
    border:none;
    margin-top:0px;
    float:center;
    margin-left:430px;
    border-radius: 100px;
    margin-top:20px;
    outline:none;
    cursor: pointer;
    
}
#sub2 {
    
    cursor: pointer;
    background:#1a73e8;
    font-family: 'Google Sans',arial,sans-serif;
    color:#fff;
    font-weight: bold;
    width:360px;
    height:50px;
    line-height: 20px;
    padding:8px;
    font-size: 16px;
    letter-spacing: .25px;
    border:none;
    margin-top:0px;
    float:center;
    margin-left:430px;
    border-radius: 100px;
    margin-top:15px;
    outline:none;

}
#block1 {
    width:100%;
}

</style>
<link href="https://fonts.googleapis.com/css?family=Molengo" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lekton" rel="stylesheet">
<div class="img"><img src="https://lh3.googleusercontent.com/8k-E0CX6s7fYwEhBPG6d_R1oxfLOHvYJtm4Fs2f7-kypdnbMGpjZVYHl9oKNPuIBjuk" width=70 peight=70><div class="name">RussianPetition</div></div>
   <div class="slogan">Изменим Россию к лучшему!</div>
   <div id="block1">
   
   <a href="vkreg.php"><input type="submit" value="Войдите через VK" id="sub"></a>
   </div>
  
   
   <a href="registration.php"><input type="submit" value="Войдите через Google" id="sub2"></a>
 